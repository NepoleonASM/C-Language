﻿// Server.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include <WinSock2.h>
#include <Windows.h>
using namespace std;
#include <Proto.h>
#include "mysql.h"
#pragma comment(lib, "libmysql.lib")
int main()
{
    //创建socket
    CUMTSocket sockServer;
    sockServer.Accept("0.0.0.0", 9527);

    MYSQL* sqlConn = mysql_init(nullptr);
    sqlConn = mysql_real_connect(sqlConn,
        nullptr,
        "root",
        "toor",
        "sims",
        3306,
        NULL,
        0);

    if (sqlConn == NULL)
    {
        cout << "连接失败" << endl;
        return 0;
    }

    mysql_set_character_set(sqlConn, "gbk");

    while (true)
    {
        PackageHeader* pPkg = nullptr;
        int nRet = RecvPack(&sockServer, pPkg);
        if (nRet == 0 || nRet == -1)
        {
            printf("connection disconnected or error ... \r\n");
            return 0;
        }

        switch (pPkg->m_pc)
        {
        case C2S_SEARCHDATA:
        {
            C2SSearchPkg* pSerachPkg = (C2SSearchPkg*)pPkg;
            int nRet = mysql_real_query(sqlConn, pSerachPkg->m_bufSearchSqlDate, pSerachPkg->m_dwSearchSqlDataLen);
            if (nRet != 0)
            {
                cout << "查询失败" << endl;
            }
            //获取查询结果
            MYSQL_RES* res = mysql_store_result(sqlConn);
            //遍历列
            int nColCnt = mysql_field_count(sqlConn);
            MYSQL_FIELD* fields = mysql_fetch_fields(res);
            //遍历记录
            MYSQL_ROW row;
            int nID = 0;
            int nSqlID = 0;
            string szSearchData;
            //将查询到的结果全部拼接成一个然后发送个客户端
            while (row = mysql_fetch_row(res))
            {
                for (size_t i=0;i< nColCnt;i++)
                {
                    szSearchData += "----";
                    szSearchData += row[i];
                    
                }
                szSearchData += "++++";
            }
            auto ptrPkg = make_package<S2CSearchPkg>(sizeof(S2CSearchPkg) + szSearchData.length() + 1,
                (char*)szSearchData.c_str(), szSearchData.length() + 1);
            SendPack(&sockServer, ptrPkg.get());
            mysql_free_result(res);
            break;
        }
        case C2S_ADDDATA:
        {
            C2SAdd_Del_UpdataPkg* pAddSqlPkg = (C2SAdd_Del_UpdataPkg*)pPkg;
            int nRet = mysql_real_query(sqlConn, pAddSqlPkg->m_bufAddSqlDate, pAddSqlPkg->m_dwAddSqlDataLen);
            if (nRet != 0)
            {
                cout << "添加失败" << endl;
            }

            break;
        }
        default:
            break;
        }
        delete (char*)pPkg;
    }



}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
