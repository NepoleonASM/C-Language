﻿// CAddStu.cpp: 实现文件
//

#include "pch.h"
#include "SIMS.h"
#include "CAddStu.h"
#include "SIMSDlg.h"
#include "afxdialogex.h"
#include <string>
#include "Functions.h"
using namespace std;
// CAddStu 对话框

IMPLEMENT_DYNAMIC(CAddStu, CDialogEx)

CAddStu::CAddStu(CWnd* pParent /*=nullptr*/)
    : CDialogEx(DLG_ADD_STU, pParent)
    , m_strID(_T(""))
    , m_strName(_T(""))
{

}

CAddStu::~CAddStu()
{
}

void CAddStu::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Text(pDX, EDT_ID, m_strID);
    DDX_Text(pDX, EDT_NAME, m_strName);
    DDX_Control(pDX, IDC_COMBO1, m_comClass);
}


BEGIN_MESSAGE_MAP(CAddStu, CDialogEx)
    ON_BN_CLICKED(BTN_OK, &CAddStu::OnBnClickedOk)
    ON_BN_CLICKED(BTN_CANCEL, &CAddStu::OnBnClickedCancel)
END_MESSAGE_MAP()


// CAddStu 消息处理程序


void CAddStu::OnBnClickedOk()
{



    CSIMSDlg* pDlg = (CSIMSDlg*)(AfxGetApp()->GetMainWnd());

    CString strSql = "INSERT INTO t_student(id,class_id,name) VALUES (\"";
    UpdateData(TRUE);
    if (m_strID.GetLength() == 0 || m_strName.GetLength() == 0)
    {
        AfxMessageBox("学号或姓名不允许为空");
        return;
    }
    strSql += m_strID;
    strSql += "\",\"";

    int nSel = m_comClass.GetCurSel();
    DWORD dwID = m_comClass.GetItemData(nSel);
    CString strID;
    strID.Format("%d", dwID);

    strSql += strID;
    strSql += "\",\"";
    strSql += m_strName;
    strSql += "\")";

    auto ptrPkg = make_package<C2SAdd_Del_UpdataPkg>(sizeof(C2SAdd_Del_UpdataPkg) + strSql.GetLength() + 1,
        (char*)strSql.GetBuffer(), strSql.GetLength() + 1);
    SendPack(&pDlg->m_sockClient, ptrPkg.get());

    //int nRet = mysql_real_query(pDlg->m_sqlConn, strSql.GetBuffer(), strSql.GetLength());
    //if (nRet != 0)
    //{
    //    AfxMessageBox("增加失败");
    //    return;
    //}
    EndDialog(0);
    return;
}


void CAddStu::OnBnClickedCancel()
{
    EndDialog(0);
}


BOOL CAddStu::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    CSIMSDlg* pDlg = (CSIMSDlg*)(AfxGetApp()->GetMainWnd());
    string strSqlS = "select * from t_class";
    auto ptrPkg = make_package<C2SSearchPkg>(sizeof(C2SSearchPkg) + strSqlS.length() + 1,
        (char*)strSqlS.c_str(), strSqlS.length() + 1);
    SendPack(&pDlg->m_sockClient, ptrPkg.get());
    PackageHeader* pPkg = nullptr;

    int nRet = RecvPack(&pDlg->m_sockClient, pPkg);
    if (nRet == 0 || nRet == -1)
    {
        AfxMessageBox("ShowInfo error ... \r\n");
        return FALSE;
    }
    S2CSearchPkg* pSerachPkg = (S2CSearchPkg*)pPkg;
    CString strBuff = pSerachPkg->m_bufSearchSqlDate;
    int nRowCount = 0;
    int nColCount = 0;

    CStringArray* splitStr = DivString(strBuff, "++++", &nRowCount);
    int idx = 0;
    DWORD id = 0;

    for (size_t i=0;i< nRowCount;i++)
    {
        CString strStuInfo = splitStr->GetAt(i);
        CStringArray* splitSytInfo = DivString(strStuInfo, "----", &nColCount);//每一列进行分割
        idx = m_comClass.AddString(splitSytInfo->GetAt(2));
        id = atoi(splitSytInfo->GetAt(1));
        m_comClass.SetItemData(idx, id);
    }
    m_comClass.SetCurSel(0);

    return TRUE;
}
