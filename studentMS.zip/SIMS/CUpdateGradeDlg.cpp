﻿// CUpdateGradeDlg.cpp: 实现文件
//

#include "pch.h"
#include "SIMS.h"
#include "CUpdateGradeDlg.h"
#include "afxdialogex.h"
#include "SIMSDlg.h"
#include <string>
using namespace std;

// CUpdateGradeDlg 对话框

IMPLEMENT_DYNAMIC(CUpdateGradeDlg, CDialogEx)

CUpdateGradeDlg::CUpdateGradeDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(DLG_UPDATE_GRADE, pParent)
    , m_strName(_T(""))
    , m_strClassName(_T(""))
    , m_strCourseName(_T(""))
    , m_strScore(_T(""))
{

}

CUpdateGradeDlg::~CUpdateGradeDlg()
{
}

void CUpdateGradeDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Text(pDX, EDT_ID, m_strName);
    DDX_Text(pDX, EDT_NAME, m_strClassName);
    DDX_Text(pDX, EDT_ID2, m_strCourseName);
    DDX_Text(pDX, EDT_ID3, m_strScore);
}


BEGIN_MESSAGE_MAP(CUpdateGradeDlg, CDialogEx)
    ON_BN_CLICKED(BTN_OK, &CUpdateGradeDlg::OnBnClickedOk)
    ON_BN_CLICKED(BTN_CANCEL, &CUpdateGradeDlg::OnBnClickedCancel)
    ON_COMMAND(MN_ADD, &CUpdateGradeDlg::OnAdd)
END_MESSAGE_MAP()


// CUpdateGradeDlg 消息处理程序


void CUpdateGradeDlg::OnBnClickedOk()
{
    UpdateData(true);

    CSIMSDlg* pDlg = (CSIMSDlg*)(AfxGetApp()->GetMainWnd());
    string strSqlS = "update t_grade set score=\"";
    int nIdx = pDlg->m_lstcAllInfo.GetSelectionMark();
    int nID = pDlg->m_lstcAllInfo.GetItemData(nIdx);
    strSqlS += m_strScore;
    strSqlS += "\" where id=";
    strSqlS += to_string(nID);

    auto ptrPkg = make_package<C2SAdd_Del_UpdataPkg>(sizeof(C2SAdd_Del_UpdataPkg) + strSqlS.length() + 1,
        (char*)strSqlS.c_str(), strSqlS.length() + 1);
    SendPack(&pDlg->m_sockClient, ptrPkg.get());
    //int nRet = mysql_real_query(pDlg->m_sqlConn, strSqlS.c_str(), strSqlS.length());
    //if (nRet != 0)
    //{
    //    AfxMessageBox("修改失败");
    //}
    EndDialog(0);
}


void CUpdateGradeDlg::OnBnClickedCancel()
{
    EndDialog(0);
}


BOOL CUpdateGradeDlg::OnInitDialog()
{
    CDialogEx::OnInitDialog();
    CSIMSDlg* pDlg = (CSIMSDlg*)(AfxGetApp()->GetMainWnd());


    int nIdx = pDlg->m_lstcAllInfo.GetSelectionMark();
    m_strName = pDlg->m_lstcAllInfo.GetItemText(nIdx, 1);
    m_strClassName = pDlg->m_lstcAllInfo.GetItemText(nIdx, 0);
    m_strCourseName = pDlg->m_lstcAllInfo.GetItemText(nIdx, 2);
    m_strScore = pDlg->m_lstcAllInfo.GetItemText(nIdx, 3);

    UpdateData(FALSE);
    

    return TRUE;  
}


void CUpdateGradeDlg::OnAdd()
{
    
}
