﻿// CAddCourseDlg.cpp: 实现文件
//

#include "pch.h"
#include "SIMS.h"
#include "CAddCourseDlg.h"
#include "afxdialogex.h"
#include "SIMSDlg.h"


// CAddCourseDlg 对话框

IMPLEMENT_DYNAMIC(CAddCourseDlg, CDialogEx)

CAddCourseDlg::CAddCourseDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(DLG_COURSE, pParent)
    , m_strID(_T(""))
    , m_strName(_T(""))
{

}

CAddCourseDlg::~CAddCourseDlg()
{
}

void CAddCourseDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Text(pDX, EDT_ID, m_strID);
    DDX_Text(pDX, EDT_NAME, m_strName);
}


BEGIN_MESSAGE_MAP(CAddCourseDlg, CDialogEx)
    ON_BN_CLICKED(BTN_OK, &CAddCourseDlg::OnBnClickedOk)
    ON_BN_CLICKED(BTN_CANCEL, &CAddCourseDlg::OnBnClickedCancel)
END_MESSAGE_MAP()


// CAddCourseDlg 消息处理程序


void CAddCourseDlg::OnBnClickedOk()
{
    CSIMSDlg* pDlg = (CSIMSDlg*)(AfxGetApp()->GetMainWnd());
    CString strSql = "INSERT INTO t_course(id,name) VALUES (\"";
    UpdateData(TRUE);
    if (m_strID.GetLength() == 0 || m_strName.GetLength() == 0)
    {
        AfxMessageBox("课程ID或名称不允许为空");
        return;
    }
    strSql += m_strID;
    strSql += "\",\"";
    strSql += m_strName;
    strSql += "\")";


    auto ptrPkg = make_package<C2SAdd_Del_UpdataPkg>(sizeof(C2SAdd_Del_UpdataPkg) + strSql.GetLength() + 1,
        (char*)strSql.GetBuffer(), strSql.GetLength() + 1);
    SendPack(&pDlg->m_sockClient, ptrPkg.get());

    EndDialog(0);
    return;
}


void CAddCourseDlg::OnBnClickedCancel()
{
    EndDialog(0);
}
