﻿// CUpdateCourse.cpp: 实现文件
//

#include "pch.h"
#include "SIMS.h"
#include "CUpdateCourse.h"
#include "afxdialogex.h"
#include "SIMSDlg.h"
#include <string>
using namespace std;

// CUpdateCourse 对话框

IMPLEMENT_DYNAMIC(CUpdateCourse, CDialogEx)

CUpdateCourse::CUpdateCourse(CWnd* pParent /*=nullptr*/)
	: CDialogEx(DLG_UPDATE_COURSE, pParent)
    , m_strName(_T(""))
{

}

CUpdateCourse::~CUpdateCourse()
{
}

void CUpdateCourse::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Text(pDX, EDT_NAME, m_strName);
}


BEGIN_MESSAGE_MAP(CUpdateCourse, CDialogEx)
    ON_BN_CLICKED(BTN_OK, &CUpdateCourse::OnBnClickedOk)
    ON_BN_CLICKED(BTN_CANCEL, &CUpdateCourse::OnBnClickedCancel)
END_MESSAGE_MAP()


// CUpdateCourse 消息处理程序


void CUpdateCourse::OnBnClickedOk()
{
    UpdateData(true);

    CSIMSDlg* pDlg = (CSIMSDlg*)(AfxGetApp()->GetMainWnd());
    string strSqlS = "update t_course set name=\"";
    int nIdx = pDlg->m_lstcAllInfo.GetSelectionMark();
    int nID = pDlg->m_lstcAllInfo.GetItemData(nIdx);
    strSqlS += m_strName;
    strSqlS += "\" where id=\"";
    strSqlS += to_string(nID);
    strSqlS += "\"";
    auto ptrPkg = make_package<C2SAdd_Del_UpdataPkg>(sizeof(C2SAdd_Del_UpdataPkg) + strSqlS.length() + 1,
        (char*)strSqlS.c_str(), strSqlS.length() + 1);
    SendPack(&pDlg->m_sockClient, ptrPkg.get());
    //int nRet = mysql_real_query(pDlg->m_sqlConn, strSqlS.c_str(), strSqlS.length());
    //if (nRet != 0)
    //{
    //    AfxMessageBox("修改失败");
    //}
    EndDialog(0);
}


void CUpdateCourse::OnBnClickedCancel()
{
    EndDialog(0);
}


BOOL CUpdateCourse::OnInitDialog()
{
    CDialogEx::OnInitDialog();


    CSIMSDlg* pDlg = (CSIMSDlg*)(AfxGetApp()->GetMainWnd());


    int nIdx = pDlg->m_lstcAllInfo.GetSelectionMark();
    m_strName = pDlg->m_lstcAllInfo.GetItemText(nIdx, 0);
    UpdateData(FALSE);


    return TRUE;  // return TRUE unless you set the focus to a control
                  // 异常: OCX 属性页应返回 FALSE
}
