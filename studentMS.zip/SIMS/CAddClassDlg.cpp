﻿// CAddClassDlg.cpp: 实现文件
//

#include "pch.h"
#include "SIMS.h"
#include "CAddClassDlg.h"
#include "afxdialogex.h"
#include "SIMSDlg.h"


// CAddClassDlg 对话框

IMPLEMENT_DYNAMIC(CAddClassDlg, CDialogEx)

CAddClassDlg::CAddClassDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(DLG_ADD_CLASS, pParent)
    , m_strName(_T(""))
    , m_strID(_T(""))
{

}

CAddClassDlg::~CAddClassDlg()
{
}

void CAddClassDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Text(pDX, EDT_NAME, m_strName);
    DDX_Text(pDX, EDT_ID, m_strID);
}


BEGIN_MESSAGE_MAP(CAddClassDlg, CDialogEx)
    ON_BN_CLICKED(BTN_OK, &CAddClassDlg::OnBnClickedOk)
    ON_BN_CLICKED(BTN_CANCEL, &CAddClassDlg::OnBnClickedCancel)
END_MESSAGE_MAP()


// CAddClassDlg 消息处理程序


void CAddClassDlg::OnBnClickedOk()
{
    CSIMSDlg* pDlg = (CSIMSDlg*)(AfxGetApp()->GetMainWnd());
    CString strSql = "INSERT INTO t_class(id,name) VALUES (\"";
    UpdateData(TRUE);
    if (m_strID.GetLength() == 0 || m_strName.GetLength() == 0)
    {
        AfxMessageBox("班级ID或名称不允许为空");
        return;
    }
    strSql += m_strID;
    strSql += "\",\"";
    strSql += m_strName;
    strSql += "\")";
    auto ptrPkg = make_package<C2SAdd_Del_UpdataPkg>(sizeof(C2SAdd_Del_UpdataPkg) + strSql.GetLength() + 1,
        (char*)strSql.GetBuffer(), strSql.GetLength() + 1);
    SendPack(&pDlg->m_sockClient, ptrPkg.get());
    EndDialog(0);
    return;
}


void CAddClassDlg::OnBnClickedCancel()
{
    EndDialog(0);
}
