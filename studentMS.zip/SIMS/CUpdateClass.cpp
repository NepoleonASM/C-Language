﻿// CUpdateClass.cpp: 实现文件
//

#include "pch.h"
#include "SIMS.h"
#include "CUpdateClass.h"
#include "afxdialogex.h"
#include "SIMSDlg.h"
#include <string>
using namespace std;

// CUpdateClass 对话框

IMPLEMENT_DYNAMIC(CUpdateClass, CDialogEx)

CUpdateClass::CUpdateClass(CWnd* pParent /*=nullptr*/)
    : CDialogEx(DLG_UPDATE_CLASS, pParent)
    , m_strName(_T(""))
{

}

CUpdateClass::~CUpdateClass()
{
}

void CUpdateClass::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Text(pDX, EDT_NAME, m_strName);
}


BEGIN_MESSAGE_MAP(CUpdateClass, CDialogEx)
    ON_BN_CLICKED(BTN_OK, &CUpdateClass::OnBnClickedOk)
    ON_BN_CLICKED(BTN_CANCEL, &CUpdateClass::OnBnClickedCancel)
END_MESSAGE_MAP()


// CUpdateClass 消息处理程序


void CUpdateClass::OnBnClickedOk()
{
    UpdateData(true);
    CSIMSDlg* pDlg = (CSIMSDlg*)(AfxGetApp()->GetMainWnd());
    string strSqlS = "update t_class set name=\"";
    int nIdx = pDlg->m_lstcAllInfo.GetSelectionMark();
    int nID = pDlg->m_lstcAllInfo.GetItemData(nIdx);
    strSqlS += m_strName;
    strSqlS += "\" where id=\"";
    strSqlS += to_string(nID);
    strSqlS += "\"";
    auto ptrPkg = make_package<C2SAdd_Del_UpdataPkg>(sizeof(C2SAdd_Del_UpdataPkg) + strSqlS.length() + 1,
        (char*)strSqlS.c_str(), strSqlS.length() + 1);
    SendPack(&pDlg->m_sockClient, ptrPkg.get());
    //int nRet = mysql_real_query(pDlg->m_sqlConn, strSqlS.c_str(), strSqlS.length());
    //if (nRet != 0)
    //{
    //    AfxMessageBox("修改失败");
    //}
    EndDialog(0);
}


void CUpdateClass::OnBnClickedCancel()
{
    EndDialog(0);
}


BOOL CUpdateClass::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    CSIMSDlg* pDlg = (CSIMSDlg*)(AfxGetApp()->GetMainWnd());


    int nIdx = pDlg->m_lstcAllInfo.GetSelectionMark();
    m_strName = pDlg->m_lstcAllInfo.GetItemText(nIdx, 0);
    UpdateData(FALSE);

    return TRUE;
}
