﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 SIMS.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SIMS_DIALOG                 102
#define IDR_MAINFRAME                   128
#define DLG_ADD_STU                     130
#define DLG_ADD_CLASS                   132
#define DLG_COURSE                      134
#define DLG_ADD_GRADE                   136
#define MN_ADU                          138
#define DLG_UPDATE_STU                  139
#define DLG_UPDATE_CLASS                141
#define DLG_UPDATE_COURSE               143
#define DLG_UPDATE_GRADE                145
#define CMB_LOC                         1000
#define BTN_ADD_STU                     1001
#define BTN_ADD_CLASS                   1002
#define EDT_ID                          1002
#define BTN_ADD_COURSE                  1003
#define EDT_NAME                        1003
#define BTN_ADD_CLASS2                  1004
#define BTN_OK                          1004
#define BTN_CANCEL                      1005
#define EDT_ID2                         1006
#define EDT_ID3                         1007
#define IDC_COMBO1                      1011
#define CMB_NAME                        1012
#define CMB_COURSE                      1014
#define IDC_EDIT4                       1015
#define EDT_SCORE                       1015
#define CMB_CLASS                       1016
#define LST_All_INFO                    1017
#define EDT_SEARCH                      1019
#define RAD_CLASS                       1020
#define RAD_COURSE                      1021
#define RAD_STU                         1022
#define RAD_SCORE                       1023
#define STC_TITLE                       1024
#define STC_SEARCH                      1025
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define MN_DEL                          32774
#define MN_UPDATE                       32775
#define MN_ADD                          32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        147
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
