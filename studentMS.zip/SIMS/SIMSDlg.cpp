﻿
// SIMSDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "SIMS.h"
#include "SIMSDlg.h"
#include "afxdialogex.h"
#include <afx.h>
#include <string>
using namespace std;
#ifdef _DEBUG
//#define new DEBUG_NEW
#endif
#include "CAddStu.h"
#include "CAddClassDlg.h"
#include "CAddCourseDlg.h"
#include "CAddGradeDlg.h"
#include "CUpdateStuDlg.h"
#include "CUpdateClass.h"
#include "CUpdateCourse.h"
#include "CUpdateGradeDlg.h"


// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
    CAboutDlg();

    // 对话框数据
#ifdef AFX_DESIGN_TIME
    enum { IDD = IDD_ABOUTBOX };
#endif

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
    DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CSIMSDlg 对话框



CSIMSDlg::CSIMSDlg(CWnd* pParent /*=nullptr*/)
    : CDialogEx(IDD_SIMS_DIALOG, pParent)
    , m_strSearch(_T(""))

    , m_nInfo(0)
{
    m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSIMSDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Control(pDX, CMB_LOC, m_comLocation);
    DDX_Control(pDX, LST_All_INFO, m_lstcAllInfo);
    DDX_Text(pDX, EDT_SEARCH, m_strSearch);
    DDX_Radio(pDX, RAD_STU, m_nInfo);
}

BEGIN_MESSAGE_MAP(CSIMSDlg, CDialogEx)
    ON_WM_SYSCOMMAND()
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
    ON_BN_CLICKED(BTN_ADD_STU, &CSIMSDlg::OnBnClickedAddStu)
    ON_BN_CLICKED(BTN_ADD_CLASS, &CSIMSDlg::OnBnClickedAddClass)
    ON_BN_CLICKED(BTN_ADD_COURSE, &CSIMSDlg::OnBnClickedAddCourse)
    ON_BN_CLICKED(BTN_ADD_CLASS2, &CSIMSDlg::OnBnClickedAddGrade)
    ON_CBN_SELCHANGE(CMB_LOC, &CSIMSDlg::OnSelchangeCmbLoc)
    ON_COMMAND(MN_DEL, &CSIMSDlg::OnDel)
    ON_NOTIFY(NM_RCLICK, LST_All_INFO, &CSIMSDlg::OnRclickLstAllInfo)
    ON_COMMAND(MN_ADD, &CSIMSDlg::OnAdd)
    ON_EN_CHANGE(EDT_SEARCH, &CSIMSDlg::OnChangeEdtSearch)
    ON_COMMAND(MN_UPDATE, &CSIMSDlg::OnUpdate)
    ON_BN_CLICKED(RAD_STU, &CSIMSDlg::OnClickedRadStu)
    ON_BN_CLICKED(RAD_CLASS, &CSIMSDlg::OnClickedRadStu)
    ON_BN_CLICKED(RAD_COURSE, &CSIMSDlg::OnClickedRadStu)
    ON_BN_CLICKED(RAD_SCORE, &CSIMSDlg::OnClickedRadStu)
END_MESSAGE_MAP()


// CSIMSDlg 消息处理程序

BOOL CSIMSDlg::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    // 将“关于...”菜单项添加到系统菜单中。

    // IDM_ABOUTBOX 必须在系统命令范围内。
    ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
    ASSERT(IDM_ABOUTBOX < 0xF000);

    CMenu* pSysMenu = GetSystemMenu(FALSE);
    if (pSysMenu != nullptr)
    {
        BOOL bNameValid;
        CString strAboutMenu;
        bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
        ASSERT(bNameValid);
        if (!strAboutMenu.IsEmpty())
        {
            pSysMenu->AppendMenu(MF_SEPARATOR);
            pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
        }
    }

    // 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
    //  执行此操作
    SetIcon(m_hIcon, TRUE);			// 设置大图标
    SetIcon(m_hIcon, FALSE);		// 设置小图标

    // TODO: 在此添加额外的初始化代码
    int nIdx = 0;
    m_lstcAllInfo.InsertColumn(nIdx++, "学号", LVCFMT_CENTER, 120);
    m_lstcAllInfo.InsertColumn(nIdx++, "姓名", LVCFMT_CENTER, 120);
    m_lstcAllInfo.InsertColumn(nIdx++, "班级", LVCFMT_CENTER, 120);

    m_sockClient.Connect("127.0.0.1", 9527);
    //m_bRunning = TRUE;
    //thread(&CSIMSDlg::WorkThread, this).detach();


    //m_sqlConn = mysql_init(nullptr);
    //m_sqlConn = mysql_real_connect(m_sqlConn, nullptr, "root", "toor", "sims", 3306, NULL, 0);
    //if (m_sqlConn == NULL)
    //{
    //    AfxMessageBox("连接失败");
    //}
    //mysql_set_character_set(m_sqlConn, "gbk");


    string strSql = "select * from t_class";
    auto ptrPkg = make_package<C2SSearchPkg>(sizeof(C2SSearchPkg) + strSql.length() + 1,
        (char*)strSql.c_str(), strSql.length() + 1);
    SendPack(&m_sockClient, ptrPkg.get());

    //int nRet = mysql_real_query(m_sqlConn, strSql.c_str(), strSql.length());
    //if (nRet != 0)
    //{
    //    AfxMessageBox("班级遍历失败");
    //}
    //获取查询结果
    //MYSQL_RES* res = mysql_store_result(m_sqlConn);

    ////遍历列
    //int nColCnt = mysql_field_count(m_sqlConn);
    //MYSQL_FIELD* fields = mysql_fetch_fields(res);
    //遍历记录
    //MYSQL_ROW row;
    //int nID = 0;
    //int nSqlID = 0;
    //while (row = mysql_fetch_row(res))
    //{
    //    nID = m_comLocation.AddString(row[1]);
    //    int nSqlID = atoi(row[0]);
    //    m_comLocation.SetItemData(nID, nSqlID);
    //}
    //m_comLocation.SetCurSel(0);
    //mysql_free_result(res);
    PackageHeader* pPkg = nullptr;

    int nRet = RecvPack(&m_sockClient, pPkg);
    if (nRet == 0 || nRet == -1)
    {
        printf("RecvPack error ... \r\n");
        return 0;
    }
    S2CSearchPkg* pSerachPkg = (S2CSearchPkg*)pPkg;
    CString strBuff = pSerachPkg->m_bufSearchSqlDate;
    int nRowCount = 0;
    int nColCount = 0;
    CStringArray* splitStr = DivString(strBuff, "++++", &nRowCount);//每一行进行分割
    int nID = 0;
    int nSqlID = 0;
    for (size_t i = 0; i < nRowCount; i++)
    {
        CString strStuInfo = splitStr->GetAt(i);
        CStringArray* splitSytInfo = DivString(strStuInfo, "----", &nColCount);//每一列进行分割
        int nID = m_comLocation.AddString(splitSytInfo->GetAt(2));
        int nSqlID = atoi(splitSytInfo->GetAt(1));
        m_comLocation.SetItemData(nID, nSqlID);
    }
    m_comLocation.SetCurSel(0);
    
    delete (char*)pPkg;
    ShowInfo();

    CWnd* pWnd = GetDlgItem(STC_TITLE);
    CWnd* pWndSearch = GetDlgItem(STC_SEARCH);
    m_cfontTitle.CreatePointFont(230, _T("宋体"), NULL);
    pWnd->SetFont(&m_cfontTitle);

    m_cfontSearch.CreatePointFont(170, _T("宋体"), NULL);
    pWndSearch->SetFont(&m_cfontSearch);


    return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CSIMSDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
    if ((nID & 0xFFF0) == IDM_ABOUTBOX)
    {
        CAboutDlg dlgAbout;
        dlgAbout.DoModal();
    }
    else
    {
        CDialogEx::OnSysCommand(nID, lParam);
    }
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CSIMSDlg::OnPaint()
{
    if (IsIconic())
    {
        CPaintDC dc(this); // 用于绘制的设备上下文

        SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

        // 使图标在工作区矩形中居中
        int cxIcon = GetSystemMetrics(SM_CXICON);
        int cyIcon = GetSystemMetrics(SM_CYICON);
        CRect rect;
        GetClientRect(&rect);
        int x = (rect.Width() - cxIcon + 1) / 2;
        int y = (rect.Height() - cyIcon + 1) / 2;

        // 绘制图标
        dc.DrawIcon(x, y, m_hIcon);
    }
    else
    {
        CDialogEx::OnPaint();
    }
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CSIMSDlg::OnQueryDragIcon()
{
    return static_cast<HCURSOR>(m_hIcon);
}



//void CSIMSDlg::WorkThread()
//{
//    while (m_bRunning)
//    {
//        PackageHeader* pPkg = nullptr;
//        int nRet = RecvPack(&m_sockClient, pPkg);
//        if (nRet == 0)
//        {
//            OutputDebugString("connection disconnected or error ... \r\n");
//            return;
//        }
//        else if (nRet == -1)
//        {
//            OutputDebugString("RecvPack failed  ... \r\n");
//            continue;
//        }
//
//        switch (pPkg->m_pc)
//        {
//        case S2C_SEARCHDATA:
//        {
//            S2CSearchPkg* pSDPkg = (S2CSearchPkg*)pPkg;
//            //m_mtxFoSD.lock();
//            //m_ptrSDPkg = shared_ptr<S2CScreenDataPkg>(pSDPkg);
//            //m_mtxFoSD.unlock();
//
//            InvalidateRect(NULL, FALSE);
//
//            pPkg = NULL;
//            break;
//        }
//        default:
//            break;
//        }
//
//        if (pPkg != NULL)
//        {
//            delete (char*)pPkg;
//        }
//    }
//}

void CSIMSDlg::OnBnClickedAddStu()
{
    CAddStu dlg;
    dlg.DoModal();
    ShowInfo();
}


void CSIMSDlg::OnBnClickedAddClass()
{
    CAddClassDlg dlg;
    dlg.DoModal();
    this->OnSelchangeCmbLoc();
}


void CSIMSDlg::OnBnClickedAddCourse()
{
    CAddCourseDlg dlg;
    dlg.DoModal();
    this->OnSelchangeCmbLoc();
}


void CSIMSDlg::OnBnClickedAddGrade()
{
    CAddGradeDlg dlg;
    dlg.DoModal();
    this->OnSelchangeCmbLoc();
}


void CSIMSDlg::ShowInfo()
{
    m_lstcAllInfo.DeleteAllItems();

    CString strSql = "select * from t_student where class_id=";

    int nIdx = m_comLocation.GetCurSel();
    int nId = m_comLocation.GetItemData(nIdx);

    strSql += to_string(nId).c_str();

    auto ptrPkg = make_package<C2SSearchPkg>(sizeof(C2SSearchPkg) + strSql.GetLength() + 1,
        (char*)strSql.GetBuffer(), strSql.GetLength() + 1);
    SendPack(&m_sockClient, ptrPkg.get());
    PackageHeader* pPkg = nullptr;

    int nRet = RecvPack(&m_sockClient, pPkg);
    if (nRet == 0 || nRet == -1)
    {
        AfxMessageBox("ShowInfo error ... \r\n");
        return;
    }
    S2CSearchPkg* pSerachPkg = (S2CSearchPkg*)pPkg;



    //int nRet = mysql_real_query(m_sqlConn, strSql.GetBuffer(), strSql.GetLength());
    //if (nRet != 0)
    //{
    //    AfxMessageBox("查询失败");
    //    return;
    //}
    //获取查询结果
    //MYSQL_RES* res = mysql_store_result(m_sqlConn);
    ////遍历列
    //int nColCnt = mysql_field_count(m_sqlConn);//返回上次执行语句的结果列的数目。
    //MYSQL_FIELD* fields = mysql_fetch_fields(res);//返回所有字段结构的数组。
    char szTemp[256] = {};
    char szTempName[256] = {};
    char szTempTel[256] = {};
    char szTempAddress[256] = {};
    int nRow = 0;
    int nCol = 1;

    //遍历记录
    //MYSQL_ROW row;//MYSQL_ROW是char **，说明字符串的指针数组
    CString strClass;
    strClass.GetBufferSetLength(128);
    int nLen = m_comLocation.GetLBText(nIdx, strClass.GetBuffer());
    strClass.ReleaseBuffer(nLen);

    CString strBuff = pSerachPkg->m_bufSearchSqlDate;
    int nRowCount = 0;
    int nColCount = 0;
    CStringArray* splitStr = DivString(strBuff, "++++", &nRowCount);//每一行进行分割
    int nID = 0;
    int nSqlID = 0;
    for (size_t i = 0; i < nRowCount; i++)
    {
        CString strStuInfo = splitStr->GetAt(i);
        CStringArray* splitSytInfo = DivString(strStuInfo, "----", &nColCount);//每一列进行分割

        nCol = 1;
        string strID = "";
        m_lstcAllInfo.InsertItem(nRow, splitSytInfo->GetAt(1));
        m_lstcAllInfo.SetItemText(nRow, nCol++, splitSytInfo->GetAt(3));

        strID = splitSytInfo->GetAt(1);
        int nID = atoi(strID.c_str());
        m_lstcAllInfo.SetItemData(nRow, nID);

        m_lstcAllInfo.SetItemText(nRow++, nCol++, strClass.GetBuffer());

    }
    delete (char*)pPkg;


    //while (row = mysql_fetch_row(res))
    //{

        //nCol = 1;
        //string strID = "";
        //m_lstcAllInfo.InsertItem(nRow, row[0]);
        //m_lstcAllInfo.SetItemText(nRow, nCol++, row[2]);

        //strID = row[0];
        //int nID = atoi(strID.c_str());
        //m_lstcAllInfo.SetItemData(nRow, nID);

        //m_lstcAllInfo.SetItemText(nRow++, nCol++, strClass.GetBuffer());
    //}
    //mysql_free_result(res);
    m_lstcAllInfo.SetExtendedStyle(m_lstcAllInfo.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
}


void CSIMSDlg::OnSelchangeCmbLoc()
{
    UpdateData(TRUE);
    switch (m_nInfo)
    {
    case 0:
        ShowStuInfo();//第一次为了重新构造listbox
        ShowInfo();//这一次是为了显示具体哪个班级的学生信息
        break;
    case 1:
        ShowClassInfo();
        break;
    case 2:
        ShowCourseInfo();
        break;
    case 3:
        ShowGradeInfo();
        break;
    default:
        break;
    }
}


void CSIMSDlg::OnDel()
{
    UpdateData(TRUE);
    switch (m_nInfo)
    {
    case 0:
        DelStu();
        break;
    case 1:
        DelClass();
        break;
    case 2:
        DelCourse();
        break;
    case 3:
        DelGrade();
        break;
    default:
        break;
    }
}


void CSIMSDlg::OnRclickLstAllInfo(NMHDR* pNMHDR, LRESULT* pResult)
{
    LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
    // TODO: 在此添加控件通知处理程序代码
    *pResult = 0;

    CMenu mn;
    mn.LoadMenu(MN_ADU);
    CMenu* pSubMn = mn.GetSubMenu(0);

    POINT pt = pNMItemActivate->ptAction;
    m_lstcAllInfo.ClientToScreen(&pt);
    pSubMn->TrackPopupMenu(TPM_LEFTALIGN, pt.x, pt.y, this);
    *pResult = 0;
}


void CSIMSDlg::OnAdd()
{
    UpdateData(TRUE);
    switch (m_nInfo)
    {
    case 0:
        this->OnBnClickedAddStu();
        this->OnSelchangeCmbLoc();
        break;
    case 1:
        this->OnBnClickedAddClass();
        this->OnSelchangeCmbLoc();
        break;
    case 2:
        this->OnBnClickedAddCourse();
        this->OnSelchangeCmbLoc();
        break;
    case 3:
        this->OnBnClickedAddGrade();
        this->OnSelchangeCmbLoc();
        break;
    default:
        break;
    }

}


void CSIMSDlg::OnChangeEdtSearch()
{
    // TODO:  如果该控件是 RICHEDIT 控件，它将不
    // 发送此通知，除非重写 CDialogEx::OnInitDialog()
    // 函数并调用 CRichEditCtrl().SetEventMask()，
    // 同时将 ENM_CHANGE 标志“或”运算到掩码中。

    // TODO:  在此添加控件通知处理程序代码
    UpdateData(TRUE);
    switch (m_nInfo)
    {
    case 0:
        ShowStuInfo();
        break;
    case 1:
        ShowClassInfo();
        break;
    case 2:
        ShowCourseInfo();
        break;
    case 3:
        break;
    default:
        break;
    }
}


void CSIMSDlg::ShowStuInfo()
{
    m_lstcAllInfo.DeleteAllItems();
    while (m_lstcAllInfo.DeleteColumn(0));

    int nIdx = 0;
    m_lstcAllInfo.InsertColumn(nIdx++, "学号", LVCFMT_CENTER, 120);
    m_lstcAllInfo.InsertColumn(nIdx++, "姓名", LVCFMT_CENTER, 120);
    m_lstcAllInfo.InsertColumn(nIdx++, "班级", LVCFMT_CENTER, 120);
    CString strSql = "select * from t_student where id like \"%";
    UpdateData(TRUE);
    
    strSql += m_strSearch.GetBuffer();
    strSql += "%\" or name like \"%";
    strSql += m_strSearch.GetBuffer();
    strSql += "%\"";

    auto ptrPkg = make_package<C2SSearchPkg>(sizeof(C2SSearchPkg) + strSql.GetLength() + 1,
        (char*)strSql.GetBuffer(), strSql.GetLength() + 1);
    SendPack(&m_sockClient, ptrPkg.get());






    //int nRet = mysql_real_query(m_sqlConn, strSql.GetBuffer(), strSql.GetLength());
    //if (nRet != 0)
    //{
    //    //AfxMessageBox("查询失败");
    //    return;
    //}
    ////获取查询结果
    //MYSQL_RES* res = mysql_store_result(m_sqlConn);
    ////遍历列
    //int nColCnt = mysql_field_count(m_sqlConn);//返回上次执行语句的结果列的数目。
    //MYSQL_FIELD* fields = mysql_fetch_fields(res);//返回所有字段结构的数组。


    char szTemp[256] = {};
    char szTempName[256] = {};
    char szTempTel[256] = {};
    char szTempAddress[256] = {};
    int nRow = 0;
    int nCol = 1;

    PackageHeader* pPkg = nullptr;

    int nRet = RecvPack(&m_sockClient, pPkg);
    if (nRet == 0 || nRet == -1)
    {
        AfxMessageBox("RecvPack error ... \r\n");
        return;
    }
    S2CSearchPkg* pSerachPkg = (S2CSearchPkg*)pPkg;
    CString strBuff = pSerachPkg->m_bufSearchSqlDate;
    int nRowCount = 0;
    int nColCount = 0;
    CStringArray* splitStr = DivString(strBuff, "++++", &nRowCount);//每一行进行分割
    if (nRowCount == 0)
    {
        ShowInfo();
        return;
    }
    for (size_t i = 0; i < nRowCount; i++)
    {
        CString strStuInfo = splitStr->GetAt(i);
        CStringArray* splitSytInfo = DivString(strStuInfo, "----", &nColCount);//每一列进行分割
        nCol = 1;
        string strID = "";
        m_lstcAllInfo.InsertItem(nRow, splitSytInfo->GetAt(1));
        m_lstcAllInfo.SetItemText(nRow, nCol++, splitSytInfo->GetAt(3));


        strID = splitSytInfo->GetAt(1);
        int nID = atoi(strID.c_str());
        m_lstcAllInfo.SetItemData(nRow, nID);
        CString strSqlClass = "select * from t_class where id=";
        strID = splitSytInfo->GetAt(2);
        strSqlClass += strID.c_str();



        auto ptrPkgIn = make_package<C2SSearchPkg>(sizeof(C2SSearchPkg) + strSqlClass.GetLength() + 1,
            (char*)strSqlClass.GetBuffer(), strSqlClass.GetLength() + 1);
        nRet = SendPack(&m_sockClient, ptrPkgIn.get());
        if (nRet < 0)
        {
            //AfxMessageBox("查询失败");
            return;
        }

        PackageHeader* pPkgIn = nullptr;
        int nRet = RecvPack(&m_sockClient, pPkgIn);
        if (nRet == 0 || nRet == -1)
        {
            AfxMessageBox("RecvPack error ... \r\n");
            return;
        }
        S2CSearchPkg* pSerachPkgIn = (S2CSearchPkg*)pPkgIn;
        CString strBuffIn = pSerachPkgIn->m_bufSearchSqlDate;
        int nRowCountIn = 0;
        int nColCountIn = 0;
        CStringArray* splitStrIn = DivString(strBuffIn, "++++", &nRowCountIn);//每一行进行分割
        if (nRowCountIn == 0)
        {
            //ShowInfo();
            return;
        }
        for (size_t i = 0; i < nRowCountIn; i++)
        {
            CString strStuInfoIn = splitStrIn->GetAt(i);
            CStringArray* splitSytInfoIn = DivString(strStuInfoIn, "----", &nColCountIn);//每一列进行分割
            m_lstcAllInfo.SetItemText(nRow++, nCol++, splitSytInfoIn->GetAt(2));
        }

    }
    delete (char*)pPkg;



    ////遍历记录
    //MYSQL_ROW row;//MYSQL_ROW是char **，说明字符串的指针数组
    //while (row = mysql_fetch_row(res))
    //{
    //    nCol = 1;
    //    string strID = "";
    //    m_lstcAllInfo.InsertItem(nRow, row[0]);
    //    m_lstcAllInfo.SetItemText(nRow, nCol++, row[2]);

    //    strID = row[0];
    //    int nID = atoi(strID.c_str());
    //    m_lstcAllInfo.SetItemData(nRow, nID);
    //    CString strSqlClass = "select * from t_class where id=";
    //    strID = row[1];
    //    strSqlClass += strID.c_str();
    //    nRet = mysql_real_query(m_sqlConn, strSqlClass.GetBuffer(), strSqlClass.GetLength());
    //    if (nRet != 0)
    //    {
    //        //AfxMessageBox("查询失败");
    //        return;
    //    }
    //    //获取查询结果
    //    MYSQL_RES* resClass = mysql_store_result(m_sqlConn);
    //    MYSQL_ROW rowClass;
    //    rowClass = mysql_fetch_row(resClass);
    //    if (rowClass == nullptr)
    //    {
    //        ShowInfo();
    //        return;
    //    }
    //    m_lstcAllInfo.SetItemText(nRow++, nCol++, rowClass[1]);
    //    mysql_free_result(resClass);
    //}
    //mysql_free_result(res);
    UpdateData(FALSE);
    m_lstcAllInfo.SetExtendedStyle(m_lstcAllInfo.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);

}


void CSIMSDlg::ShowCourseInfo()
{
    m_lstcAllInfo.DeleteAllItems();
    while (m_lstcAllInfo.DeleteColumn(0));
    int nIdx = 0;
    m_lstcAllInfo.InsertColumn(nIdx++, "课程名称", LVCFMT_CENTER, 90);
    CString strSql = "select * from t_course where name like \"%";
    UpdateData(TRUE);
    strSql += m_strSearch.GetBuffer();
    strSql += "%\"";



    auto ptrPkg = make_package<C2SSearchPkg>(sizeof(C2SSearchPkg) + strSql.GetLength() + 1,
        (char*)strSql.GetBuffer(), strSql.GetLength() + 1);
    SendPack(&m_sockClient, ptrPkg.get());
    char szTemp[256] = {};
    char szTempName[256] = {};
    char szTempTel[256] = {};
    char szTempAddress[256] = {};
    int nRow = 0;
    int nCol = 1;
    PackageHeader* pPkg = nullptr;

    int nRet = RecvPack(&m_sockClient, pPkg);
    if (nRet == 0 || nRet == -1)
    {
        AfxMessageBox("RecvPack error ... \r\n");
        return;
    }
    S2CSearchPkg* pSerachPkg = (S2CSearchPkg*)pPkg;
    CString strBuff = pSerachPkg->m_bufSearchSqlDate;
    int nRowCount = 0;
    int nColCount = 0;
    CStringArray* splitStr = DivString(strBuff, "++++", &nRowCount);//每一行进行分割
    for (size_t i = 0; i < nRowCount; i++)
    {
        CString strStuInfo = splitStr->GetAt(i);
        CStringArray* splitSytInfo = DivString(strStuInfo, "----", &nColCount);//每一列进行分割

        nCol = 1;
        string strID = "";
        m_lstcAllInfo.InsertItem(nRow, splitSytInfo->GetAt(2));
        strID = splitSytInfo->GetAt(1);
        int nID = atoi(strID.c_str());
        m_lstcAllInfo.SetItemData(nRow++, nID);

    }

    delete (char*)pPkg;
    m_lstcAllInfo.SetExtendedStyle(m_lstcAllInfo.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
}


void CSIMSDlg::ShowClassInfo()
{
    m_lstcAllInfo.DeleteAllItems();
    while (m_lstcAllInfo.DeleteColumn(0));
    int nIdx = 0;
    m_lstcAllInfo.InsertColumn(nIdx++, "班级名称", LVCFMT_CENTER, 90);
    CString strSql = "select * from t_class where name like \"%";
    UpdateData(TRUE);
    strSql += m_strSearch.GetBuffer();
    strSql += "%\"";
    auto ptrPkg = make_package<C2SSearchPkg>(sizeof(C2SSearchPkg) + strSql.GetLength() + 1,
        (char*)strSql.GetBuffer(), strSql.GetLength() + 1);
    SendPack(&m_sockClient, ptrPkg.get());


    char szTemp[256] = {};
    char szTempName[256] = {};
    char szTempTel[256] = {};
    char szTempAddress[256] = {};
    int nRow = 0;
    int nCol = 1;
    PackageHeader* pPkg = nullptr;

    int nRet = RecvPack(&m_sockClient, pPkg);
    if (nRet == 0 || nRet == -1)
    {
        AfxMessageBox("RecvPack error ... \r\n");
        return;
    }
    S2CSearchPkg* pSerachPkg = (S2CSearchPkg*)pPkg;
    CString strBuff = pSerachPkg->m_bufSearchSqlDate;
    int nRowCount = 0;
    int nColCount = 0;
    CStringArray* splitStr = DivString(strBuff, "++++", &nRowCount);//每一行进行分割

    for (size_t i = 0; i < nRowCount; i++)
    {
        CString strStuInfo = splitStr->GetAt(i);
        CStringArray* splitSytInfo = DivString(strStuInfo, "----", &nColCount);//每一列进行分割
        nCol = 1;
        string strID = "";
        m_lstcAllInfo.InsertItem(nRow, splitSytInfo->GetAt(2));
        strID = splitSytInfo->GetAt(1);
        int nID = atoi(strID.c_str());
        m_lstcAllInfo.SetItemData(nRow++, nID);
    }
    delete (char*)pPkg;
    m_lstcAllInfo.SetExtendedStyle(m_lstcAllInfo.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
}


void CSIMSDlg::DelStu()
{
    CString strSql = "delete from t_student where id=";
    int nIdx = m_lstcAllInfo.GetSelectionMark();

    CString strId = m_lstcAllInfo.GetItemText(nIdx, 0);

    strSql += strId.GetBuffer();

    auto ptrPkg = make_package<C2SAdd_Del_UpdataPkg>(sizeof(C2SAdd_Del_UpdataPkg) + strSql.GetLength() + 1,
        (char*)strSql.GetBuffer(), strSql.GetLength() + 1);
    SendPack(&m_sockClient, ptrPkg.get());


    //int nRet = mysql_real_query(m_sqlConn, strSql.GetBuffer(), strSql.GetLength());
    //if (nRet != 0)
    //{
    //    AfxMessageBox("未选中任何一项删除失败");
    //    return;
    //}
    //Sleep(1000);
    OnChangeEdtSearch();
}


void CSIMSDlg::DelClass()
{
    CString strSql = "delete from t_class where id=";
    int nIdx = m_lstcAllInfo.GetSelectionMark();

    //CString strId = m_lstcAllInfo.GetItemText(nIdx, 0);
    int nID= m_lstcAllInfo.GetItemData(nIdx);
    CString strId;
    strId.Format("%d", nID);

    strSql += strId.GetBuffer();
    auto ptrPkg = make_package<C2SAdd_Del_UpdataPkg>(sizeof(C2SAdd_Del_UpdataPkg) + strSql.GetLength() + 1,
        (char*)strSql.GetBuffer(), strSql.GetLength() + 1);
    SendPack(&m_sockClient, ptrPkg.get());
    //int nRet = mysql_real_query(m_sqlConn, strSql.GetBuffer(), strSql.GetLength());
    //if (nRet != 0)
    //{
    //    AfxMessageBox("未选中任何一项删除失败");
    //    return;
    //}
    //Sleep(1000);
    OnChangeEdtSearch();
}


void CSIMSDlg::DelCourse()
{
    CString strSql = "delete from t_course where id=";
    int nIdx = m_lstcAllInfo.GetSelectionMark();

    int nID = m_lstcAllInfo.GetItemData(nIdx);
    CString strId;
    strId.Format("%d", nID);

    strSql += strId.GetBuffer();

    auto ptrPkg = make_package<C2SAdd_Del_UpdataPkg>(sizeof(C2SAdd_Del_UpdataPkg) + strSql.GetLength() + 1,
        (char*)strSql.GetBuffer(), strSql.GetLength() + 1);
    SendPack(&m_sockClient, ptrPkg.get());
    //int nRet = mysql_real_query(m_sqlConn, strSql.GetBuffer(), strSql.GetLength());
    //if (nRet != 0)
    //{
    //    AfxMessageBox("未选中任何一项删除失败");
    //    return;
    //}
    //Sleep(1000);//为了防止立马请求数据库不能及时更新的情况
    OnChangeEdtSearch();
}



void CSIMSDlg::OnUpdate()
{
    UpdateData(TRUE);
    switch (m_nInfo)
    {
    case 0:
        this->OnBnClickedUpdateStu();
        break;
    case 1:
        this->OnBnClickedUpdateClass();
        break;
    case 2:
        this->OnBnClickedUpdateCourse();
        break;
    case 3:
        this->OnBnClickedUpdateGrade();
        break;
    default:
        break;
    }
}


void CSIMSDlg::OnBnClickedUpdateStu()
{
    CUpdateStuDlg dlg;
    dlg.DoModal();
    OnChangeEdtSearch();
}


void CSIMSDlg::OnBnClickedUpdateClass()
{
    CUpdateClass dlg;
    dlg.DoModal();
    OnChangeEdtSearch();
}


void CSIMSDlg::OnBnClickedUpdateCourse()
{
    CUpdateCourse dlg;
    dlg.DoModal();
    OnChangeEdtSearch();
}


void CSIMSDlg::ShowGradeInfo()
{
    m_lstcAllInfo.DeleteAllItems();
    while (m_lstcAllInfo.DeleteColumn(0));

    int nIdx = 0;
    m_lstcAllInfo.InsertColumn(nIdx++, "班级", LVCFMT_CENTER, 120);
    m_lstcAllInfo.InsertColumn(nIdx++, "姓名", LVCFMT_CENTER, 120);
    m_lstcAllInfo.InsertColumn(nIdx++, "课程名称", LVCFMT_CENTER, 120);
    m_lstcAllInfo.InsertColumn(nIdx++, "成绩", LVCFMT_CENTER, 120);
    CString strSql = "select * from t_grade";



    auto ptrPkg = make_package<C2SSearchPkg>(sizeof(C2SSearchPkg) + strSql.GetLength() + 1,
        (char*)strSql.GetBuffer(), strSql.GetLength() + 1);
    SendPack(&m_sockClient, ptrPkg.get());


    char szTemp[256] = {};
    char szTempName[256] = {};
    char szTempTel[256] = {};
    char szTempAddress[256] = {};
    int nRow = 0;
    int nCol = 1;
    nIdx = m_comLocation.GetCurSel();
    int nClassId = m_comLocation.GetItemData(nIdx);
    CString strClassName;
    strClassName.GetBufferSetLength(128);
    int nRet = m_comLocation.GetLBText(nIdx, strClassName.GetBuffer());
    strClassName.ReleaseBuffer(nRet);

    PackageHeader* pPkg = nullptr;
    nRet = RecvPack(&m_sockClient, pPkg);
    if (nRet == 0 || nRet == -1)
    {
        AfxMessageBox("RecvPack error ... \r\n");
        return;
    }
    S2CSearchPkg* pSerachPkg = (S2CSearchPkg*)pPkg;
    CString strBuff = pSerachPkg->m_bufSearchSqlDate;
    int nRowCount = 0;
    int nColCount = 0;
    CStringArray* splitStr = DivString(strBuff, "++++", &nRowCount);//每一行进行分割

    for (size_t i = 0; i < nRowCount; i++)
    {
        CString strStuInfo = splitStr->GetAt(i);
        CStringArray* splitSytInfo = DivString(strStuInfo, "----", &nColCount);//每一列进行分割


        nCol = 1;
        string strID = "";
        CString strSqlStudent = "select name from t_student where id=\"";

        strSqlStudent += splitSytInfo->GetAt(1);
        strSqlStudent += "\" and class_id=\"";
        strSqlStudent += to_string(nClassId).c_str();
        strSqlStudent += "\"";

        auto ptrPkg_in = make_package<C2SSearchPkg>(sizeof(C2SSearchPkg) + strSqlStudent.GetLength() + 1,
            (char*)strSqlStudent.GetBuffer(), strSqlStudent.GetLength() + 1);
        SendPack(&m_sockClient, ptrPkg_in.get());

        PackageHeader* pPkg_in = nullptr;

        int nRet_in = RecvPack(&m_sockClient, pPkg_in);
        if (nRet_in == 0 || nRet_in == -1)
        {
            printf("RecvPack error ... \r\n");
            return;
        }
        S2CSearchPkg* pSerachPkg_in = (S2CSearchPkg*)pPkg_in;
        CString strBuff_in = pSerachPkg_in->m_bufSearchSqlDate;
        int nRowCount_in = 0;
        int nColCount_in = 0;
        CStringArray* splitStr_in = DivString(strBuff_in, "++++", &nRowCount_in);//每一行进行分割
        string rowIn0_in;
        for (size_t i = 0; i < nRowCount_in; i++)
        {
            CString strStuInfo_in = splitStr_in->GetAt(i);
            CStringArray* splitSytInfo_in = DivString(strStuInfo_in, "----", &nColCount_in);//每一列进行分割
            rowIn0_in = splitSytInfo_in->GetAt(1);
        }

        delete (char*)pPkg_in;

        if (nRowCount_in == 0)
        {
            continue;
        }

        int nID = atoi(splitSytInfo->GetAt(4));

        m_lstcAllInfo.InsertItem(nRow, strClassName.GetBuffer());
        m_lstcAllInfo.SetItemText(nRow, nCol++, rowIn0_in.c_str());

        CString strSqlCourse = "select name from t_course where id=\"";
        strSqlCourse += splitSytInfo->GetAt(2);
        strSqlCourse += "\"";

        auto ptrPkgin_in = make_package<C2SSearchPkg>(sizeof(C2SSearchPkg) + strSqlCourse.GetLength() + 1,
            (char*)strSqlCourse.GetBuffer(), strSqlCourse.GetLength() + 1);
        SendPack(&m_sockClient, ptrPkgin_in.get());

        PackageHeader* pPkgin_in = nullptr;

        int nRet_in_in = RecvPack(&m_sockClient, pPkgin_in);
        if (nRet_in_in == 0 || nRet_in_in == -1)
        {
            printf("RecvPack error ... \r\n");
            return;
        }
        S2CSearchPkg* pSerachPkg_in_in = (S2CSearchPkg*)pPkgin_in;
        CString strBuff_in_in = pSerachPkg_in_in->m_bufSearchSqlDate;
        int nRowCount_in_in = 0;
        int nColCount_in_in = 0;
        CStringArray* splitStr_in_in = DivString(strBuff_in_in, "++++", &nRowCount_in_in);//每一行进行分割

        if (nRowCount_in_in == 0)
        {
            return;
        }
        for (size_t i = 0; i < nRowCount_in_in; i++)
        {
            CString strStuInfo_in_in = splitStr_in_in->GetAt(i);
            CStringArray* splitSytInfo_in_in = DivString(strStuInfo_in_in, "----", &nColCount_in_in);//每一列进行分割
            m_lstcAllInfo.SetItemText(nRow, nCol++, splitSytInfo_in_in->GetAt(1));
            m_lstcAllInfo.SetItemText(nRow, nCol++, splitSytInfo->GetAt(3));
            m_lstcAllInfo.SetItemData(nRow++, nID);
        }

        delete (char*)pPkgin_in;


        //    if (nRet != 0)
//    {
//        //AfxMessageBox("查询失败");
//        return;
//    }
//    //获取查询结果
//    MYSQL_RES* resCourse = mysql_store_result(m_sqlConn);
//    MYSQL_ROW rowCourse;
//    rowCourse = mysql_fetch_row(resCourse);
//    if (rowStudent == nullptr)
//    {
//        return;
//    }
//    m_lstcAllInfo.SetItemText(nRow, nCol++, rowCourse[0]);
//    m_lstcAllInfo.SetItemText(nRow, nCol++, row[2]);
//    m_lstcAllInfo.SetItemData(nRow++, nID);
//    mysql_free_result(resStudent);

    }

    delete (char*)pPkg;


    //while (row = mysql_fetch_row(res))
    //{
    //    nCol = 1;
    //    string strID = "";
    //    CString strSqlStudent = "select name from t_student where id=\"";
    //    strSqlStudent += row[0];
    //    strSqlStudent += "\" and class_id=\"";
    //    strSqlStudent += to_string(nClassId).c_str();
    //    strSqlStudent += "\"";
    //    nRet = mysql_real_query(m_sqlConn, strSqlStudent.GetBuffer(), strSqlStudent.GetLength());
    //    if (nRet != 0)
    //    {
    //        //AfxMessageBox("查询失败");
    //        return;
    //    }
    //    //获取查询结果
    //    MYSQL_RES* resStudent = mysql_store_result(m_sqlConn);
    //    MYSQL_ROW rowStudent;
    //    rowStudent = mysql_fetch_row(resStudent);
    //    if (rowStudent == nullptr)
    //    {
    //        continue;
    //    }
    //    int nID = atoi(row[3]);
    //    m_lstcAllInfo.InsertItem(nRow, strClassName.GetBuffer());
    //    m_lstcAllInfo.SetItemText(nRow, nCol++, rowStudent[0]);

    //    CString strSqlCourse = "select name from t_course where id=\"";
    //    strSqlCourse += row[1];
    //    strSqlCourse += "\"";

    //    nRet = mysql_real_query(m_sqlConn, strSqlCourse.GetBuffer(), strSqlCourse.GetLength());
    //    if (nRet != 0)
    //    {
    //        //AfxMessageBox("查询失败");
    //        return;
    //    }
    //    //获取查询结果
    //    MYSQL_RES* resCourse = mysql_store_result(m_sqlConn);
    //    MYSQL_ROW rowCourse;
    //    rowCourse = mysql_fetch_row(resCourse);
    //    if (rowStudent == nullptr)
    //    {
    //        return;
    //    }
    //    m_lstcAllInfo.SetItemText(nRow, nCol++, rowCourse[0]);
    //    m_lstcAllInfo.SetItemText(nRow, nCol++, row[2]);
    //    m_lstcAllInfo.SetItemData(nRow++, nID);
    //    mysql_free_result(resStudent);
    //}
    //mysql_free_result(res);
    m_lstcAllInfo.SetExtendedStyle(m_lstcAllInfo.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);

}


void CSIMSDlg::OnBnClickedUpdateGrade()
{
    CUpdateGradeDlg dlg;
    dlg.DoModal();
    this->OnSelchangeCmbLoc();
}


void CSIMSDlg::DelGrade()
{
    CString strSql = "delete from t_grade where id=";
    int nIdx = m_lstcAllInfo.GetSelectionMark();
    int nID = m_lstcAllInfo.GetItemData(nIdx);
    strSql += to_string(nID).c_str();


    auto ptrPkg = make_package<C2SAdd_Del_UpdataPkg>(sizeof(C2SAdd_Del_UpdataPkg) + strSql.GetLength() + 1,
        (char*)strSql.GetBuffer(), strSql.GetLength() + 1);
    SendPack(&m_sockClient, ptrPkg.get());
    //int nRet = mysql_real_query(m_sqlConn, strSql.GetBuffer(), strSql.GetLength());
    //if (nRet != 0)
    //{
    //    AfxMessageBox("未选中任何一项删除失败");
    //    return;
    //}
    //Sleep(1000);
    this->OnSelchangeCmbLoc();
}


CStringArray* CSIMSDlg::DivString(CString strSrc, CString strSing, int* pNum)
{
    CStringArray* m_result = new CStringArray;
    *pNum = 0;
    while (TRUE)
    {
        int index = strSrc.Find(_T(strSing.GetBuffer()));
        if (index == -1)
        {
            m_result->Add(strSrc);
            //*pNum = *pNum + 1;
            return m_result;
        }
        CString splitStr = strSrc.Left(index);
        m_result->Add(splitStr);
        *pNum = *pNum + 1;
        strSrc = strSrc.Right(strSrc.GetLength() - index - strSing.GetLength());
    }
}


void CSIMSDlg::OnClickedRadStu()
{
    this->OnSelchangeCmbLoc();
}
