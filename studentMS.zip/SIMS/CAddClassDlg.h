﻿#pragma once


// CAddClassDlg 对话框

class CAddClassDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CAddClassDlg)

public:
	CAddClassDlg(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CAddClassDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = DLG_ADD_CLASS };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:

    CString m_strName;
    afx_msg void OnBnClickedOk();
    afx_msg void OnBnClickedCancel();
    CString m_strID;
};
