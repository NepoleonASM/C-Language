﻿#pragma once


// CUpdateCourse 对话框

class CUpdateCourse : public CDialogEx
{
	DECLARE_DYNAMIC(CUpdateCourse)

public:
	CUpdateCourse(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CUpdateCourse();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = DLG_UPDATE_COURSE };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnBnClickedOk();
    afx_msg void OnBnClickedCancel();
    CString m_strName;
    virtual BOOL OnInitDialog();
};
