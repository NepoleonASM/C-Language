﻿#pragma once


// CUpdateStuDlg 对话框

class CUpdateStuDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CUpdateStuDlg)

public:
	CUpdateStuDlg(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CUpdateStuDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = DLG_UPDATE_STU };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
    CString m_strID;
    CString m_strName;
    CComboBox m_cmbClass;
    afx_msg void OnBnClickedOk();
    afx_msg void OnBnClickedCancel();
    virtual BOOL OnInitDialog();
};
