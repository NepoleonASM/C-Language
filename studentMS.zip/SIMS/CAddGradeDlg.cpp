﻿// CAddGradeDlg.cpp: 实现文件
//

#include "pch.h"
#include "SIMS.h"
#include "CAddGradeDlg.h"
#include "afxdialogex.h"
#include "SIMSDlg.h"

#include <string>
#include <Functions.h>
using namespace std;
// CAddGradeDlg 对话框

IMPLEMENT_DYNAMIC(CAddGradeDlg, CDialogEx)

CAddGradeDlg::CAddGradeDlg(CWnd* pParent /*=nullptr*/)
    : CDialogEx(DLG_ADD_GRADE, pParent)
    , m_strScore(_T(""))
{

}

CAddGradeDlg::~CAddGradeDlg()
{
}

void CAddGradeDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Control(pDX, CMB_CLASS, m_cmbClass);
    DDX_Control(pDX, CMB_NAME, m_cmbName);
    DDX_Control(pDX, CMB_COURSE, m_cmbCourse);
    DDX_Text(pDX, EDT_SCORE, m_strScore);
}


BEGIN_MESSAGE_MAP(CAddGradeDlg, CDialogEx)
    ON_BN_CLICKED(BTN_OK, &CAddGradeDlg::OnBnClickedOk)
    ON_BN_CLICKED(BTN_CANCEL, &CAddGradeDlg::OnBnClickedCancel)
    ON_CBN_SELCHANGE(CMB_CLASS, &CAddGradeDlg::OnSelchangeCmbClass)
END_MESSAGE_MAP()


// CAddGradeDlg 消息处理程序


void CAddGradeDlg::OnBnClickedOk()
{
    CSIMSDlg* pDlg = (CSIMSDlg*)(AfxGetApp()->GetMainWnd());

    CString strSql = "INSERT INTO t_grade(stu_id,course_id,score) VALUES (";
    UpdateData(TRUE);
    if (m_cmbClass.GetCurSel()== CB_ERR || m_cmbCourse.GetCurSel() == 
        CB_ERR||m_cmbName.GetCurSel()== CB_ERR)
    {
        AfxMessageBox("班级或姓名课程或不允许为空");
        return;
    }


    int nSel = m_cmbName.GetCurSel();
    DWORD dwID = m_cmbName.GetItemData(nSel);
    strSql += to_string(dwID).c_str();
    strSql += ",\"";
    nSel = m_cmbCourse.GetCurSel();
    dwID = m_cmbCourse.GetItemData(nSel);
    strSql += to_string(dwID).c_str();
    strSql += "\",";
    strSql += m_strScore;
    strSql += ")";


    auto ptrPkg = make_package<C2SAdd_Del_UpdataPkg>(sizeof(C2SAdd_Del_UpdataPkg) + strSql.GetLength() + 1,
        (char*)strSql.GetBuffer(), strSql.GetLength() + 1);
    SendPack(&pDlg->m_sockClient, ptrPkg.get());



    //int nRet = mysql_real_query(pDlg->m_sqlConn, strSql.GetBuffer(), strSql.GetLength());
    //if (nRet != 0)
    //{
    //    AfxMessageBox("增加失败");
    //    return;
    //}
    EndDialog(0);
}


void CAddGradeDlg::OnBnClickedCancel()
{
    EndDialog(0);
}


void CAddGradeDlg::OnSelchangeCmbClass()
{
    CSIMSDlg* pDlg = (CSIMSDlg*)(AfxGetApp()->GetMainWnd());
    int nSel = m_cmbClass.GetCurSel();
    int nID = m_cmbClass.GetItemData(nSel);
    string strSqlS = "select * from t_student where class_id=\"" + to_string(nID) + "\"";


    auto ptrPkg = make_package<C2SSearchPkg>(sizeof(C2SSearchPkg) + strSqlS.length() + 1,
        (char*)strSqlS.c_str(), strSqlS.length() + 1);
    SendPack(&pDlg->m_sockClient, ptrPkg.get());


    m_cmbName.ResetContent();
    PackageHeader* pPkg = nullptr;

    int nRet = RecvPack(&pDlg->m_sockClient, pPkg);
    if (nRet == 0 || nRet == -1)
    {
        printf("RecvPack error ... \r\n");
        return;
    }
    S2CSearchPkg* pSerachPkg = (S2CSearchPkg*)pPkg;
    CString strBuff = pSerachPkg->m_bufSearchSqlDate;
    int nRowCount = 0;
    int nColCount = 0;
    CStringArray* splitStr = DivString(strBuff, "++++", &nRowCount);//每一行进行分割
    int idx = 0;
    DWORD id = 0;
    for (size_t i = 0; i < nRowCount; i++)
    {
        CString strStuInfo = splitStr->GetAt(i);
        CStringArray* splitSytInfo = DivString(strStuInfo, "----", &nColCount);//每一列进行分割
        idx = m_cmbName.AddString(splitSytInfo->GetAt(3));
        id = atoi(splitSytInfo->GetAt(1));
        m_cmbName.SetItemData(idx, id);
    }

    delete (char*)pPkg;
    m_cmbName.SetCurSel(0);

}


BOOL CAddGradeDlg::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    CSIMSDlg* pDlg = (CSIMSDlg*)(AfxGetApp()->GetMainWnd());
    string strSqlS = "select * from t_class";

    auto ptrPkg = make_package<C2SSearchPkg>(sizeof(C2SSearchPkg) + strSqlS.length() + 1,
        (char*)strSqlS.c_str(), strSqlS.length() + 1);
    SendPack(&pDlg->m_sockClient, ptrPkg.get());
    PackageHeader* pPkg = nullptr;

    int nRet = RecvPack(&pDlg->m_sockClient, pPkg);
    if (nRet == 0 || nRet == -1)
    {
        printf("RecvPack error ... \r\n");
        return 0;
    }
    S2CSearchPkg* pSerachPkg = (S2CSearchPkg*)pPkg;
    CString strBuff = pSerachPkg->m_bufSearchSqlDate;
    int nRowCount = 0;
    int nColCount = 0;
    CStringArray* splitStr = DivString(strBuff, "++++", &nRowCount);//每一行进行分割
    int idx = 0;
    DWORD id = 0;
    for (size_t i = 0; i < nRowCount; i++)
    {
        CString strStuInfo = splitStr->GetAt(i);
        CStringArray* splitSytInfo = DivString(strStuInfo, "----", &nColCount);//每一列进行分割
        idx = m_cmbClass.AddString(splitSytInfo->GetAt(2));
        id = atoi(splitSytInfo->GetAt(1));
        m_cmbClass.SetItemData(idx, id);
    }
    m_cmbClass.SetCurSel(0);

    strSqlS.clear();
    strSqlS = "select * from t_course";

    auto ptrPkg_in = make_package<C2SSearchPkg>(sizeof(C2SSearchPkg) + strSqlS.length() + 1,
        (char*)strSqlS.c_str(), strSqlS.length() + 1);
    SendPack(&pDlg->m_sockClient, ptrPkg_in.get());
    PackageHeader* pPkg_in = nullptr;

    int nRet_in = RecvPack(&pDlg->m_sockClient, pPkg_in);
    if (nRet_in == 0 || nRet_in == -1)
    {
        printf("RecvPack error ... \r\n");
        return 0;
    }
    S2CSearchPkg* pSerachPkg_in = (S2CSearchPkg*)pPkg_in;
    CString strBuff_in = pSerachPkg_in->m_bufSearchSqlDate;
    int nRowCount_in = 0;
    int nColCount_in = 0;
    CStringArray* splitStr_in = DivString(strBuff_in, "++++", &nRowCount_in);//每一行进行分割
    for (size_t i = 0; i < nRowCount_in; i++)
    {
        CString strStuInfo_in = splitStr_in->GetAt(i);
        CStringArray* splitSytInfo_in = DivString(strStuInfo_in, "----", &nColCount_in);//每一列进行分割
        idx = m_cmbCourse.AddString(splitSytInfo_in->GetAt(2));
        id = atoi(splitSytInfo_in->GetAt(1));
        m_cmbCourse.SetItemData(idx, id);

    }
    m_cmbCourse.SetCurSel(0);

   
    strSqlS.clear();
    int nSel = m_cmbClass.GetCurSel();
    int nID = m_cmbClass.GetItemData(nSel);
    strSqlS = "select * from t_student where class_id=\"" + to_string(nID) + "\"";


    auto ptrPkg_in_in = make_package<C2SSearchPkg>(sizeof(C2SSearchPkg) + strSqlS.length() + 1,
        (char*)strSqlS.c_str(), strSqlS.length() + 1);
    SendPack(&pDlg->m_sockClient, ptrPkg_in_in.get());
    PackageHeader* pPkg_in_in = nullptr;

    int nRet_in_in = RecvPack(&pDlg->m_sockClient, pPkg_in_in);
    if (nRet_in_in == 0 || nRet_in_in == -1)
    {
        printf("RecvPack error ... \r\n");
        return 0;
    }
    S2CSearchPkg* pSerachPkg_in_in = (S2CSearchPkg*)pPkg_in_in;
    CString strBuff_in_in = pSerachPkg_in_in->m_bufSearchSqlDate;
    int nRowCount_in_in = 0;
    int nColCount_in_in = 0;
    CStringArray* splitStr_in_in = DivString(strBuff_in_in, "++++", &nRowCount_in_in);//每一行进行分割

    for (size_t i = 0; i < nRowCount_in_in; i++)
    {
        CString strStuInfo_in_in = splitStr_in_in->GetAt(i);
        CStringArray* splitSytInfo_in_in = DivString(strStuInfo_in_in, "----", &nColCount);//每一列进行分割
        idx = m_cmbName.AddString(splitSytInfo_in_in->GetAt(3));
        id = atoi(splitSytInfo_in_in->GetAt(1));
        m_cmbName.SetItemData(idx, id);

    }

    delete (char*)pPkg_in_in;

    m_cmbName.SetCurSel(0);

    return TRUE;
}
