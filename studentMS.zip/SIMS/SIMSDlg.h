﻿
// SIMSDlg.h: 头文件
//

#pragma once
#include "mysql.h"
#pragma comment(lib, "libmysql.lib")
#include "Proto.h"
// CSIMSDlg 对话框
class CSIMSDlg : public CDialogEx
{
// 构造
public:
	CSIMSDlg(CWnd* pParent = nullptr);	// 标准构造函数

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_SIMS_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
    CUMTSocket m_sockClient;
    BOOL m_bRunning = FALSE;
    void WorkThread();
public:
    CFont m_cfontTitle;
    CFont m_cfontSearch;
    CComboBox m_comLocation;
    afx_msg void OnBnClickedAddStu();
    MYSQL* m_sqlConn;
    afx_msg void OnBnClickedAddClass();
    afx_msg void OnBnClickedAddGrade();
    afx_msg void OnBnClickedAddCourse();
    CListCtrl m_lstcAllInfo;
    void ShowInfo();
    afx_msg void OnSelchangeCmbLoc();
    afx_msg void OnDel();
    afx_msg void OnRclickLstAllInfo(NMHDR* pNMHDR, LRESULT* pResult);
    afx_msg void OnAdd();
    CString m_strSearch;
    afx_msg void OnChangeEdtSearch();
    int m_nInfo;
    void ShowStuInfo();
    void ShowCourseInfo();
    void ShowClassInfo();
    void DelStu();
    void DelClass();
    void DelCourse();
    afx_msg void OnUpdate();
    void OnBnClickedUpdateStu();
    void OnBnClickedUpdateClass();
    void OnBnClickedUpdateCourse();
    void ShowGradeInfo();
    void OnBnClickedUpdateGrade();
    void DelGrade();
    CStringArray* DivString(CString strSrc, CString strSing, int* pNum);
    afx_msg void OnClickedRadStu();
};
