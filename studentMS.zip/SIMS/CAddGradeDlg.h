﻿#pragma once


// CAddGradeDlg 对话框

class CAddGradeDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CAddGradeDlg)

public:
	CAddGradeDlg(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CAddGradeDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = DLG_ADD_GRADE };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnBnClickedOk();
    afx_msg void OnBnClickedCancel();
    CComboBox m_cmbClass;
    CComboBox m_cmbName;
    CComboBox m_cmbCourse;
    afx_msg void OnSelchangeCmbClass();
    virtual BOOL OnInitDialog();
    CString m_strScore;
};
