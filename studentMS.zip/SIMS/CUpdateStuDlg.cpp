﻿// CUpdateStuDlg.cpp: 实现文件
//

#include "pch.h"
#include "SIMS.h"
#include "CUpdateStuDlg.h"
#include "afxdialogex.h"
#include "SIMSDlg.h"
#include <string>
#include <Functions.h>
using namespace std;

// CUpdateStuDlg 对话框

IMPLEMENT_DYNAMIC(CUpdateStuDlg, CDialogEx)

CUpdateStuDlg::CUpdateStuDlg(CWnd* pParent /*=nullptr*/)
    : CDialogEx(DLG_UPDATE_STU, pParent)
    , m_strID(_T(""))
    , m_strName(_T(""))
{

}

CUpdateStuDlg::~CUpdateStuDlg()
{
}

void CUpdateStuDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Text(pDX, EDT_ID, m_strID);
    DDX_Text(pDX, EDT_NAME, m_strName);
    DDX_Control(pDX, CMB_CLASS, m_cmbClass);
}


BEGIN_MESSAGE_MAP(CUpdateStuDlg, CDialogEx)
    ON_BN_CLICKED(BTN_OK, &CUpdateStuDlg::OnBnClickedOk)
    ON_BN_CLICKED(BTN_CANCEL, &CUpdateStuDlg::OnBnClickedCancel)
END_MESSAGE_MAP()


// CUpdateStuDlg 消息处理程序


void CUpdateStuDlg::OnBnClickedOk()
{
    UpdateData(true);
    CSIMSDlg* pDlg = (CSIMSDlg*)(AfxGetApp()->GetMainWnd());
    string strSqlS = "update t_student set id=\"";
    strSqlS += m_strID;
    strSqlS += "\",class_id=\"";
    int nIdx = m_cmbClass.GetCurSel();
    int nClassID = m_cmbClass.GetItemData(nIdx);
    strSqlS += to_string(nClassID);
    strSqlS += "\",name=\"";
    strSqlS += m_strName;
    strSqlS += "\" where id=\"";
    nIdx = pDlg->m_lstcAllInfo.GetSelectionMark();
    strSqlS += pDlg->m_lstcAllInfo.GetItemText(nIdx, 0);
    strSqlS += "\"";

    auto ptrPkg = make_package<C2SAdd_Del_UpdataPkg>(sizeof(C2SAdd_Del_UpdataPkg) + strSqlS.length() + 1,
        (char*)strSqlS.c_str(), strSqlS.length() + 1);
    SendPack(&pDlg->m_sockClient, ptrPkg.get());

    //int nRet = mysql_real_query(pDlg->m_sqlConn, strSqlS.c_str(), strSqlS.length());
    //if (nRet != 0)
    //{
    //    AfxMessageBox("修改失败");
    //}
    
    EndDialog(0);
}


void CUpdateStuDlg::OnBnClickedCancel()
{
    EndDialog(0);
}


BOOL CUpdateStuDlg::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    CSIMSDlg* pDlg = (CSIMSDlg*)(AfxGetApp()->GetMainWnd());


    int nIdx = pDlg->m_lstcAllInfo.GetSelectionMark();
    m_strID = pDlg->m_lstcAllInfo.GetItemText(nIdx, 0);
    m_strName = pDlg->m_lstcAllInfo.GetItemText(nIdx, 1);

    string strSql = "select * from t_class";


    auto ptrPkg = make_package<C2SSearchPkg>(sizeof(C2SSearchPkg) + strSql.length() + 1,
        (char*)strSql.c_str(), strSql.length() + 1);
    SendPack(&pDlg->m_sockClient, ptrPkg.get());


    //int nRet = mysql_real_query(pDlg->m_sqlConn, strSql.c_str(), strSql.length());
    //if (nRet != 0)
    //{
    //    AfxMessageBox("班级遍历失败");
    //}
    ////获取查询结果
    //MYSQL_RES* res = mysql_store_result(pDlg->m_sqlConn);

    ////遍历列
    //int nColCnt = mysql_field_count(pDlg->m_sqlConn);
    //MYSQL_FIELD* fields = mysql_fetch_fields(res);
    ////遍历记录
    //MYSQL_ROW row;



    int nID = 0;
    int nSqlID = 0;

    PackageHeader* pPkg = nullptr;

    int nRet = RecvPack(&pDlg->m_sockClient, pPkg);
    if (nRet == 0 || nRet == -1)
    {
        printf("RecvPack error ... \r\n");
        return 0;
    }
    S2CSearchPkg* pSerachPkg = (S2CSearchPkg*)pPkg;
    CString strBuff = pSerachPkg->m_bufSearchSqlDate;
    int nRowCount = 0;
    int nColCount = 0;
    CStringArray* splitStr = DivString(strBuff, "++++", &nRowCount);//每一行进行分割

    for (size_t i = 0; i < nRowCount; i++)
    {
        CString strStuInfo = splitStr->GetAt(i);
        CStringArray* splitSytInfo = DivString(strStuInfo, "----", &nColCount);//每一列进行分割
        nID = m_cmbClass.AddString(splitSytInfo->GetAt(2));
        int nSqlID = atoi(splitSytInfo->GetAt(1));
        m_cmbClass.SetItemData(nID, nSqlID);
    }

    delete (char*)pPkg;


    //while (row = mysql_fetch_row(res))
    //{
    //    nID = m_cmbClass.AddString(row[1]);
    //    int nSqlID = atoi(row[0]);
    //    m_cmbClass.SetItemData(nID, nSqlID);
    //}
    m_cmbClass.SetCurSel(0);
    //mysql_free_result(res);
    UpdateData(FALSE);


    return TRUE;
}
