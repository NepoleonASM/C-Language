#include "Functions.h"


CStringArray* DivString(CString strSrc, CString strSing, int* pNum)
{
    CStringArray* m_result = new CStringArray;
    *pNum = 0;
    while (TRUE)
    {
        int index = strSrc.Find(_T(strSing.GetBuffer()));
        if (index == -1)
        {
            m_result->Add(strSrc);
            //*pNum = *pNum + 1;
            return m_result;
        }
        CString splitStr = strSrc.Left(index);
        m_result->Add(splitStr);
        *pNum  = *pNum + 1;
        strSrc = strSrc.Right(strSrc.GetLength() - index - strSing.GetLength());
    }
}
