#pragma once
class CCrc32
{
public:
    static unsigned int crc32(const unsigned char* buf, unsigned int size);
};

