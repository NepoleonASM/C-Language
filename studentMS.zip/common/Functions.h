#pragma once

#include <afx.h>

CStringArray* DivString(CString strSrc, CString strSing,int* pNum);
